﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Management.Instrumentation;

namespace Practise_1
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        public SqlConnection con1;
        public SqlCommand com;
        public SqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String c = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            con1 = new SqlConnection(c);
            try
            {
                con1.Open();
                string n = TextBox1.Text;
                string d = DropDownList1.SelectedValue;
                string b = DropDownList2.SelectedValue;
                string m = TextBox2.Text;
                String mail = TextBox3.Text;
                String id = TextBox4.Text;
                String pass = TextBox5.Text;
                string q = "insert into faculty_add1 values('" + n + "','" + d + "', '" + b + "','" + m + "','" + mail + "','" + id + "','" + pass + "')";
                com = new SqlCommand(q, con1);
                if (com.ExecuteNonQuery() > 0)
                {
                    Response.Write("<script>alert('Faculty added successfully..');</script>");

                }
                else
                    Response.Write("<script>alert('error....');</script>");
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Database error..');</script>");
            }

        }
       

        protected void Button3_Click1(object sender, EventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            DropDownList1.SelectedIndex = 0;
            DropDownList2.SelectedIndex = 0;
        }
    }
}