﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practise_1
{
    public partial class WebForm10 : System.Web.UI.Page
    {
        public SqlCommand com;
        public SqlConnection con1;
        public SqlDataAdapter da;
        public SqlDataReader dr;
        public DataSet ds;
        protected void Page_Load(object sender, EventArgs e)
        {
            String s1 = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            con1 = new SqlConnection(s1);
            try
            {
                con1.Open();
                string q = "select name from Faculty_add1";
                com = new SqlCommand(q,con1);                
                dr = com.ExecuteReader();              
                DropDownList1.DataSource = dr;             
                DropDownList1.DataValueField = "name";
                DropDownList1.DataBind();
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Database error...');</script>");

            }
            con1.Close();
            dr.Close();
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            String s1 = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            con1 = new SqlConnection(s1);
            try
            {
                con1.Open();
                string v = DropDownList1.SelectedValue.ToString();

                string q = "delete from Faculty_add1 where name='"+v+"'";
                com = new SqlCommand(q, con1);
                if(com.ExecuteNonQuery()>0)
                {
                    //DropDownList1.Items.Clear();

                    Response.Write("<script>alert('Record deleted...');</script>");
                }
                
           }
           catch(Exception ex)
           {
                Response.Write("<script>alert('Database error...');</script>");
           }
            con1.Close();
            
        }
    }
}